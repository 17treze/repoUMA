import { Indirizzo } from "./IndirizzoProxyDto";

export class SedeLegaleDto {
    indirizzo: Indirizzo;
    recTelefonico: string;
    indirizzoPEC: string;
}