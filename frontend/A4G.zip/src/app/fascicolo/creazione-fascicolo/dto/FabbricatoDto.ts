export class FabbricatoDto {
    id: number;
    ubicazione: string;
    tipologia: string;
    destinazione: string;
    superficieCoperta: number;
    superficieScoperta: number;
    volume: number;
    nrPosti: number;
    utilizzatori: string;
}