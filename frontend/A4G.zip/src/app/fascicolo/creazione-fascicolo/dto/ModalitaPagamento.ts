export class ModalitaPagamentoDto {
    [x: string]: any;
    id: number;
    iban: string;
    bic: string;
    denominazioneIstituto: string;
    denominazioneFiliale: string;
    cittaFiliale: string; 
}
