export class Indirizzo {
    toponimo: string;
    via: string;
    numeroCivico: string;
    comune: string;
    cap: string;
    codiceIstat: string;
    frazione: string;
    provincia: string;
}