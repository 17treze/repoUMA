export class NotaDichiarazioneRifiutata {
    nrProtocolloComunicazione: string;
    noteDiChiusura: string;
}