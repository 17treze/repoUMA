import { DichiarazioneAntimafia } from './dichiarazioneAntimafia';


export class DatiChiusuraExNovoDichiarazioneAntimafia {
    daChiudere: DichiarazioneAntimafia;
    exNovo: DichiarazioneAntimafia;
}