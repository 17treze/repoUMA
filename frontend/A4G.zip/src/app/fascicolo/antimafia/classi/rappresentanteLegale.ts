export class RappresentanteLegale {
  codiceFiscale: string;
  dati: string;

  constructor(codiceFiscale: string, dati: string) {
    this.codiceFiscale = codiceFiscale;
    this.dati = dati;
  }
}
