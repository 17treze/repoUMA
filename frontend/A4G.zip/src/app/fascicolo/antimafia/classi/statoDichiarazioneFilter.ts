import { StatoDichiarazione } from "./statoDichiarazioneEnum";

export class StatoDichiarazioneFilter {
  statiDichiarazione: Array<StatoDichiarazione>;
}
