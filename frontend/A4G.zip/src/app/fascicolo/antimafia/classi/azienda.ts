export class Azienda {
    id:number;
    cuaa:string;

    constructor(id?: number, cuaa?: string){
        this.id = null;
        this.cuaa = cuaa;
    };
}


