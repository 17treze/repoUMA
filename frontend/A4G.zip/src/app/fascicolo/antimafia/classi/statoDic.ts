export class StatoDic {
     id: number;
	 identificativo: string;
	 descrizione: string;
}