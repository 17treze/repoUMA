
import { DichiarazioneAntimafia } from "./dichiarazioneAntimafia";

export class DichiarazioneAntimafiaFilter extends DichiarazioneAntimafia {
  statiDichiarazione: string[];
  filtroUtenteEnte: boolean;
}
