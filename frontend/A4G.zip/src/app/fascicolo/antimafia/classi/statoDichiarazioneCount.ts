export class StatoDichiarazioneCount {
  bozza: number;
  protocollata: number;
  firmata: number;
  controlloManuale: number;
  controllata: number;
  rifiutata: number;
  verificaPeriodica: number;
  chiusa: number;
  positiva: number;
  rettificata: number;
}
