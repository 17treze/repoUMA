export class UploadFile{
    file:File;
    isFirmaDigitale: boolean;
    esitoVerificaFirma: boolean;
    fileBase64: string;
}