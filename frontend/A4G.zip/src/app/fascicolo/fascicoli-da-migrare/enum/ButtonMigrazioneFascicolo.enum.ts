export enum ButtonMigrazioneFascicolo {
    download_mandato = "download_mandato",
    carica_mandato = "carica_mandato",
    download_privacy = "download_privacy",
    carica_privacy = "carica_privacy",
    protocolla_mandato = "protocolla_mandato",
    carica_allegato = "carica_allegato",
    elimina_allegato = "elimina_allegato"
}
