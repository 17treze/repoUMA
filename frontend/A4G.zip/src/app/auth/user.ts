import { DatiUtente } from "../amministrazione/ricerca-utenti/dto/Profili";

export class Utente extends DatiUtente {
}

