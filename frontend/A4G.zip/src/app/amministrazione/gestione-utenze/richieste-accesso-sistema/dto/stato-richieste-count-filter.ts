export class StatoRichiesteCountFilter {

    public nome: string;
    public cognome: string;
    public codiceFiscale: string;
    public idProtocollo: string;

}
