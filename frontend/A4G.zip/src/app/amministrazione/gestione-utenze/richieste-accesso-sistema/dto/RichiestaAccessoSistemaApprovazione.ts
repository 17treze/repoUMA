export class RichiestaAccessoSistemaApprovazione {
    idDomanda: number;
    testoMail: String;
    note: String;
}