export class RichiestaAccessoSistemaRifiuto {
    id: number;
    idDomanda: number;
    motivazioneRifiuto: string;
    note: string;
    testoComunicazione?: string;
    testoMail: string;
    variazioneRichiesta?: string;
}
