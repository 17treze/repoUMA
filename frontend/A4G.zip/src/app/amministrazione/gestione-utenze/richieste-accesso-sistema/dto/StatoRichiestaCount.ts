export class StatoRichiestaCount {
    stato: string;
    count: number;
};