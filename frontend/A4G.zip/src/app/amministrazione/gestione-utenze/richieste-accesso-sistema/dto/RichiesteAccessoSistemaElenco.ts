import { RichiesteAccessoSistema } from "./RichiesteAccessoSistema";

export class RichiesteAccessoSistemaElenco {
    risultati: RichiesteAccessoSistema[];
    count: number = 0;
}
