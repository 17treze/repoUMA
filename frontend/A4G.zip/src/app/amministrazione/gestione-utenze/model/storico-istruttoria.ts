import {Utente} from './utente';
import {IstruttoriaPerStorico} from './istruttoria-per-storico';

export class StoricoIstruttoria {

    utente: Utente;
    istruttorie: IstruttoriaPerStorico;

}
