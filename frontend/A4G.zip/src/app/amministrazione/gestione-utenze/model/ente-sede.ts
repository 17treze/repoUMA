export class EnteSede {

    id: number;
    descrizione: string;
    identificativo: number;
    caa: string;

}
