export class CaricaDto {
  codiceFiscale: string;
  cuaa: string;
  denominazione: string;
  carica: string;
}
