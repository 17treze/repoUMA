import { ValidaCuaaCompletoDirective } from './valida-cuaa-completo.directive';

describe('ValidaCuaaCompletoDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidaCuaaCompletoDirective();
    expect(directive).toBeTruthy();
  });
});
