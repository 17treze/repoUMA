import { ValidaDenominazioneDirective } from './valida-denominazione.directive';

describe('ValidaDenominazioneDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidaDenominazioneDirective();
    expect(directive).toBeTruthy();
  });
});
