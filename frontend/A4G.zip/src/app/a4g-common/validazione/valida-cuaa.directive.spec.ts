import { ValidaCuaaDirective } from './valida-cuaa.directive';

describe('ValidaCuaaDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidaCuaaDirective();
    expect(directive).toBeTruthy();
  });
});
