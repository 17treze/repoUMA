import { ValidaCfDirective } from './valida-cf.directive';

describe('ValidaCfDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidaCfDirective();
    expect(directive).toBeTruthy();
  });
});
