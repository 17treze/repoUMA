import { ValidaNomeDirective } from './valida-nome.directive';

describe('ValidaNomeDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidaNomeDirective();
    expect(directive).toBeTruthy();
  });
});
