import { ValidaTelefonoDirective } from './valida-telefono.directive';

describe('ValidaTelefonoDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidaTelefonoDirective();
    expect(directive).toBeTruthy();
  });
});
