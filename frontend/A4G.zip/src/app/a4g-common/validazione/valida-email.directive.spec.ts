import { ValidaEmailDirective } from './valida-email.directive';

describe('ValidaEmailDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidaEmailDirective();
    expect(directive).toBeTruthy();
  });
});
