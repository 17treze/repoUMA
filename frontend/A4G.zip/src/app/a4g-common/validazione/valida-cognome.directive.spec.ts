import { ValidaCognomeDirective } from './valida-cognome.directive';

describe('ValidaCognomeDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidaCognomeDirective();
    expect(directive).toBeTruthy();
  });
});
