export class PaginatedContent<T> {
    public risultati: T[];
    public count: number;
}
