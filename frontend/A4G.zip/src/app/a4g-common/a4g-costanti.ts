export const A4gCostanti = {
    ROUTE_DATA_BREADCRUMB : "mybreadcrumb",
    ROUTE_DATA_BREADCRUMB_TRANSLATE_KEY: "breadcrumbTranslateKey"
   };
   