export type Actions = {
    save?: () => void;
    discard?: () => void;
    cancel?: () => void;
};
