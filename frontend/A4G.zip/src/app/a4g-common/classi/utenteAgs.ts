export class UtenteAgs {
    utenza: number;
    cf: number;
    descrizione: string;
}