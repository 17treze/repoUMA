import { TipoAllegatoConsuntivo } from '../enums/uma/TipoAllegatoConsuntivo.enum';
export class SelectItemTipoDocumentoViewModel {
    label: string;
    value: number;
    enum: TipoAllegatoConsuntivo;
}