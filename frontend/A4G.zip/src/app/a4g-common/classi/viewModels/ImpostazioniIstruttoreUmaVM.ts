export interface ImpostazioniIstruttoreUmaVM {
    dataDefaultPrelievo: Date;
}