import { StringDecoder } from "string_decoder";

export class UtenteA4g {
    codiceFiscale: string;
    username: string;
    nome: string;
    cognome: string;
    profilo: string;
    descProfilo: string;
    userName: string;
}
