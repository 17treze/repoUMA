export class recordTabella {
    nomeColonna: string;
    valore: string;
    //ordine: number;
}