export interface FabbricatoDto {
    id: number;
    tipologia: string;
    comune: string;
    volume: number;
    superficie: number;
}
