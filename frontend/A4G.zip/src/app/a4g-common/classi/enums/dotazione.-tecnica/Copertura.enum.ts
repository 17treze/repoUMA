export enum CoperturaEnum {
    SI = 'SI',
    NO = 'NO',
    PARZIALE = 'PARZIALE'
}