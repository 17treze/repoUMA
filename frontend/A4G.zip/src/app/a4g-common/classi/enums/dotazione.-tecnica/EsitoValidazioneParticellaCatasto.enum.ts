export enum EsitoValidazioneParticellaCatastoEnum {
    VALIDA = 'VALIDA',
    INVALIDA = 'INVALIDA'
}
