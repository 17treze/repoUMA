export enum AlimentazioneEnum {
    GASOLIO = 'GASOLIO', 
    BENZINA = 'BENZINA', 
    ELETTRICO = 'ELETTRICO'
}