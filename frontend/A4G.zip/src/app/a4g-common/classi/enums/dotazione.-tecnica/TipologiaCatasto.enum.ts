export enum TipologiaCatasto {
    EDIFICIALE = 'EDIFICIALE',
    FONDIARIA = 'FONDIARIA'
}