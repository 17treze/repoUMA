export enum TipoConduzione {
    PROPRIETA_O_COMPROPRIETA = 'PROPRIETA_O_COMPROPRIETA',// Proprietà o Comproprietà
    AFFITTO = 'AFFITTO',// Affitto
    MEZZADRIA = 'MEZZADRIA',// Mezzadria
    ALTRA_FORMA = 'ALTRA_FORMA',// Altra forma
    DECRETO_LEGGE = 'DECRETO_LEGGE' //  EST.INF. 5.000mq comune montano (DL.24/06/2014 N.91)
}