export enum TipologiaPossessoEnum {
    COMODATO = 'COMODATO',
    COMPROPRIETA = 'COMPROPRIETA',
    IN_USO = 'IN_USO',
    LEASING = 'LEASING',
    NOLEGGIO = 'NOLEGGIO',
    PROPRIETA = 'PROPRIETA'
}