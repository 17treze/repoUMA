export enum TipoElencoEnum {
    DOMANDE = 'DOMANDE', // operatore CAA e istruttore UMA
    INADEMPIENTI = 'INADEMPIENTI', // operatore CAA e istruttore UMA
    LAVORAZIONI_CLIENTI_CONTO_TERZI = 'LAVORAZIONI_CLIENTI_CONTO_TERZI', // istruttore UMA
    ACCISE = 'ACCISE' // istruttore UMA
}