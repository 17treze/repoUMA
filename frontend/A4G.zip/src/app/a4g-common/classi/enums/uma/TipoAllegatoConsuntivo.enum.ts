export enum TipoAllegatoConsuntivo {
    // tipo di documento caricato in corrispondenza del campo ammesso: UMA-03-05-F Allegati Motivo ammesso
	AUTOCERTIFICAZIONE = "AUTOCERTIFICAZIONE",
	AUTORIZZAZIONE_UMA = "AUTORIZZAZIONE_UMA",
	ALTRO = "ALTRO"
}

