export enum StatoDichiarazioneConsumiEnum {
    IN_COMPILAZIONE = 'IN_COMPILAZIONE',
    PROTOCOLLATA = 'PROTOCOLLATA'
}