export class DropdownValue {
    mkey:string;
    mvalue:string;
    
    constructor(key:string,value:string) {
    this.mkey = key;
    this.mvalue = value;
     }
    }