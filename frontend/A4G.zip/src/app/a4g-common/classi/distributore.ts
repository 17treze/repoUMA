export class Distributore {
   id: number;
   denominazioneAzienda: string;
   comune: string;
   provincia: string;
   indirizzo: string;
   dataInizio: string;
   dataFine: string;
}
