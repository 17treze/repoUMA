export class DipartimentoPat {
    denominazione: Array<string>;
}
