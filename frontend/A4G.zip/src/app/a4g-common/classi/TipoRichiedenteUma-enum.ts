export enum TipoRichiedenteUma {
    richiesta = 'richiesta',
    'dichiarazione-consumi' = 'dichiarazione-consumi'
}