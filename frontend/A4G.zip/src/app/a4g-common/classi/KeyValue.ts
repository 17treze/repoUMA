export class KeyValue {
    mkey: string;
    mvalue: string;
}
