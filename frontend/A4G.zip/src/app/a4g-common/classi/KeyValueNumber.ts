export class KeyValueNumber {
    mkey: number;
    mvalue: number;

    constructor(key: number, value: number){
        this.mkey = key;
        this.mvalue = value;
    };
}