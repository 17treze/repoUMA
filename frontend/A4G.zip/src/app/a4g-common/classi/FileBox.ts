export class FileBox {
    file: File;
    nome: string;
    showDeleteButton: boolean;
    label?: string;
}
