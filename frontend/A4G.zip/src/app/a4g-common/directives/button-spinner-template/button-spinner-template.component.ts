import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-button-spinner-template',
  templateUrl: './button-spinner-template.component.html',
  styleUrls: ['./button-spinner-template.component.scss']
})
export class ButtonSpinnerTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
