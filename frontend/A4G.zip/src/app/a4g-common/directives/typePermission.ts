export enum TypePermission {
    MODIFICABILE,
    NON_MODIFICABILE,
    VISIBILE,
    NON_VISIBILE
}